# Tamil Clock Widget (Android)

Native Android home-screen widget inspired by the supplied reference.

## Features
- Live local time in large type with AM/PM
- Gregorian date and Tamil weekday/month/date
- Selectable background colour (14 presets)
- Selectable text colour (14 presets)
- Adjustable background opacity/transparency slider
- Resizable widget for different Android home screens

## Build APK
1. Open this folder in Android Studio.
2. Allow Gradle sync and install Android SDK platform 35 if prompted.
3. Choose **Build > Build APK(s)**.
4. Debug APK path: `app/build/outputs/apk/debug/app-debug.apk`.

## Use
Install the APK. Long-press an empty home-screen area, choose **Widgets**, select **Tamil Clock Widget**, and drag it onto the home screen. Open the app to customize colours/transparency, then tap **Save and update widget**.

## Notes
The Tamil solar calendar date uses approximate month boundary dates and may be off by one day in some years. A verified annual Tamil calendar/astronomical source is needed for exact dates. Android launchers may vary in how often widget updates are delivered.
