package in.tamilclock.widget;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class TamilClockWidgetProvider extends AppWidgetProvider {
    private static final String[] WEEKDAYS = {
        "ஞாயிறு", "திங்கள்", "செவ்வாய்", "புதன்", "வியாழன்", "வெள்ளி", "சனி"
    };
    private static final String[] TAMIL_MONTHS = {
        "சித்திரை", "வைகாசி", "ஆனி", "ஆடி", "ஆவணி", "புரட்டாசி",
        "ஐப்பசி", "கார்த்திகை", "மார்கழி", "தை", "மாசி", "பங்குனி"
    };

    @Override public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        for (int id : ids) update(context, manager, id);
    }

    @Override public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        String action = intent.getAction();
        if (Intent.ACTION_TIME_TICK.equals(action) || Intent.ACTION_TIME_CHANGED.equals(action)
                || Intent.ACTION_DATE_CHANGED.equals(action) || Intent.ACTION_TIMEZONE_CHANGED.equals(action)) {
            AppWidgetManager manager = AppWidgetManager.getInstance(context);
            int[] ids = manager.getAppWidgetIds(new android.content.ComponentName(context, TamilClockWidgetProvider.class));
            for (int id : ids) update(context, manager, id);
        }
    }

    private void update(Context context, AppWidgetManager manager, int id) {
        Calendar now = Calendar.getInstance();
        Date date = now.getTime();
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_clock);
        views.setTextViewText(R.id.clock_time, new SimpleDateFormat("hh : mm a", Locale.ENGLISH).format(date));
        views.setTextViewText(R.id.gregorian_date, new SimpleDateFormat("dd - MM - yyyy", Locale.ENGLISH).format(date));
        int weekday = now.get(Calendar.DAY_OF_WEEK) - Calendar.SUNDAY;
        TamilDate tamil = tamilDate(now);
        views.setTextViewText(R.id.tamil_date, WEEKDAYS[weekday] + " - " + TAMIL_MONTHS[tamil.month] + " " + tamil.day);

        android.content.SharedPreferences prefs = context.getSharedPreferences("widget_settings", Context.MODE_PRIVATE);
        int baseColor = prefs.getInt("background_color", android.graphics.Color.BLACK);
        int alpha = prefs.getInt("background_alpha", 255);
        int bg = android.graphics.Color.argb(alpha, android.graphics.Color.red(baseColor),
                android.graphics.Color.green(baseColor), android.graphics.Color.blue(baseColor));
        int textColor = prefs.getInt("text_color", android.graphics.Color.WHITE);
        views.setInt(R.id.widget_root, "setBackgroundColor", bg);
        views.setTextColor(R.id.clock_time, textColor);
        views.setTextColor(R.id.gregorian_date, textColor);
        views.setTextColor(R.id.tamil_date, textColor);
        manager.updateAppWidget(id, views);
    }

    // Approximate Tamil solar-calendar boundaries; can be off by one day in some years.
    private TamilDate tamilDate(Calendar c) {
        int month = c.get(Calendar.MONTH);
        int day = c.get(Calendar.DAY_OF_MONTH);
        int[] starts = {14, 13, 14, 14, 15, 15, 16, 17, 17, 17, 16, 16};
        int[] tamilForGregorian = {9, 10, 11, 0, 1, 2, 3, 4, 5, 6, 7, 8};
        int start = starts[month];
        int tm = tamilForGregorian[month];
        if (day < start) {
            tm = (tm + 11) % 12;
            Calendar prev = (Calendar)c.clone();
            prev.add(Calendar.MONTH, -1);
            int previousLength = prev.getActualMaximum(Calendar.DAY_OF_MONTH);
            int previousStart = starts[(month + 11) % 12];
            return new TamilDate(tm, previousLength - previousStart + day + 1);
        }
        return new TamilDate(tm, day - start + 1);
    }

    private static class TamilDate {
        final int month, day;
        TamilDate(int month, int day) { this.month = month; this.day = Math.max(1, day); }
    }
}
