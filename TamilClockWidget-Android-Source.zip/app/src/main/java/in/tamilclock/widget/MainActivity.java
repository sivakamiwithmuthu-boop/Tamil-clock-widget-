package in.tamilclock.widget;

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

public class MainActivity extends Activity {
    private SharedPreferences prefs;
    private int selectedBackground = Color.BLACK;
    private int selectedText = Color.WHITE;
    private int alpha = 255;
    private TextView bgLabel, textLabel, alphaLabel;

    private final int[] colors = {
        Color.BLACK, Color.WHITE, Color.DKGRAY, Color.GRAY, Color.RED,
        Color.rgb(255, 128, 0), Color.YELLOW, Color.GREEN, Color.CYAN,
        Color.BLUE, Color.rgb(128, 0, 255), Color.MAGENTA,
        Color.rgb(255, 192, 203), Color.rgb(0, 128, 96)
    };
    private final String[] names = {
        "Black", "White", "Dark grey", "Grey", "Red", "Orange", "Yellow",
        "Green", "Cyan", "Blue", "Purple", "Magenta", "Pink", "Teal"
    };

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("widget_settings", MODE_PRIVATE);
        selectedBackground = prefs.getInt("background_color", Color.BLACK);
        selectedText = prefs.getInt("text_color", Color.WHITE);
        alpha = prefs.getInt("background_alpha", 255);

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(22, 22, 22, 22);
        page.setBackgroundColor(Color.BLACK);

        TextView title = new TextView(this);
        title.setText("Tamil Clock Widget settings");
        title.setTextColor(Color.WHITE);
        title.setTextSize(24);
        title.setGravity(Gravity.CENTER);
        page.addView(title, matchWrap());

        bgLabel = label("Background colour");
        page.addView(bgLabel, matchWrap());
        addColorButtons(page, false);

        textLabel = label("Text colour");
        page.addView(textLabel, matchWrap());
        addColorButtons(page, true);

        alphaLabel = label("Background transparency: " + Math.round(alpha * 100f / 255f) + "% opaque");
        page.addView(alphaLabel, matchWrap());
        SeekBar transparency = new SeekBar(this);
        transparency.setMax(255);
        transparency.setProgress(alpha);
        transparency.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar bar, int value, boolean fromUser) {
                alpha = value;
                alphaLabel.setText("Background transparency: " + (100 - Math.round(value * 100f / 255f)) + "% transparent");
            }
            public void onStartTrackingTouch(SeekBar bar) {}
            public void onStopTrackingTouch(SeekBar bar) {}
        });
        page.addView(transparency, matchWrap());

        Button save = new Button(this);
        save.setText("Save and update widget");
        save.setOnClickListener(v -> {
            prefs.edit().putInt("background_color", selectedBackground)
                .putInt("text_color", selectedText)
                .putInt("background_alpha", alpha).apply();
            AppWidgetManager manager = AppWidgetManager.getInstance(this);
            int[] ids = manager.getAppWidgetIds(new ComponentName(this, TamilClockWidgetProvider.class));
            for (int id : ids) new TamilClockWidgetProvider().onUpdate(this, manager, new int[]{id});
            android.widget.Toast.makeText(this, "Widget settings saved", android.widget.Toast.LENGTH_SHORT).show();
        });
        page.addView(save, matchWrap());
        TextView help = label("Choose colours, adjust transparency, then tap Save. Add or resize the widget from your home-screen Widgets menu.");
        page.addView(help, matchWrap());

        setContentView(page);
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    private TextView label(String value) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextColor(Color.WHITE);
        t.setTextSize(16);
        t.setPadding(0, 18, 0, 8);
        return t;
    }

    private void addColorButtons(LinearLayout page, boolean forText) {
        // Multiple rows of accessible colour choices.
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < colors.length; i++) {
            final int color = colors[i];
            Button b = new Button(this);
            b.setText(shortName(names[i]));
            b.setTextSize(9);
            b.setPadding(2, 2, 2, 2);
            b.setMinWidth(0);
            b.setMinimumWidth(0);
            b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(color));
            b.setTextColor(contrast(color));
            b.setOnClickListener(v -> {
                if (forText) {
                    selectedText = color;
                    textLabel.setText("Text colour: " + hex(color));
                } else {
                    selectedBackground = color;
                    bgLabel.setText("Background colour: " + hex(color));
                }
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, 48, 1);
            lp.setMargins(2, 2, 2, 2);
            row.addView(b, lp);
            if ((i + 1) % 4 == 0 || i == colors.length - 1) {
                page.addView(row, matchWrap());
                row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
            }
        }
    }

    private String shortName(String s) {
        if (s.equals("Dark grey")) return "D.Grey";
        return s;
    }

    private int contrast(int c) {
        double y = 0.299 * Color.red(c) + 0.587 * Color.green(c) + 0.114 * Color.blue(c);
        return y > 150 ? Color.BLACK : Color.WHITE;
    }

    private String hex(int c) { return String.format("#%06X", (0xFFFFFF & c)); }
}
